<?php

/**
 * 
 * 
 * Plugin Name: myproject
 * Description: Common Custom Post type
 * Author: Robiul hasan
 * Text Domain: myproject
 */


 

// Custom Fields section start here

function myproject_custom_posts(){

    // Slider Custom Post
    register_post_type('sliders', array(
        'labels' => array(
            'name' => __('Slides', 'myproject'),
            'singular_name' => __('Slider', 'myproject')
        ),
        'public' => true,
        'supports' => array('title', 'editor', 'thumbnail', 'custom-fields'),
        'menu_icon'  =>'dashicons-format-gallery'

    ));


        // Service Custom Post
    register_post_type('services', array(
        'labels' => array(
            'name' => __('Services', 'myproject'),
            'singular_name' => __('service', 'myproject')
        ),
        'public' => true,
        'supports' => array('title', 'editor',  'custom-fields'),
        'menu_icon'  =>'dashicons-admin-page'
    ));


          // Team section Custom Post
          register_post_type('team', array(
            'labels' => array(
                'name' => __('Teams', 'myproject'),
                'singular_name' => __('team', 'myproject')
            ),
            'public' => true,
            'supports' => array('title', 'editor','thumbnail',  'custom-fields','page-attributes'),
            'menu_icon'  =>'dashicons-admin-users'
        ));


            // testimonials section Custom Post
            register_post_type('testimonials', array(
                'labels' => array(
                    'name' => __('Testimonials', 'myproject'),
                    'singular_name' => __('testimonials', 'myproject')
                ),
                'public' => true,
                'supports' => array('title', 'thumbnail',  'custom-fields','page-attributes'),
                'menu_icon'  =>'dashicons-ellipsis'
            ));


                 // gallery section Custom Post
                 register_post_type('gallery', array(
                    'labels' => array(
                        'name' => __('Gallery', 'myproject'),
                        'singular_name' => __('gallery', 'myproject')
                    ),
                    'public' => true,
                    'supports' => array('title', 'custom-fields','page-attributes'),
                    'menu_icon'  =>'dashicons-images-alt2'
                ));


                      // portfolio section Custom Post
                      register_post_type('portfolio', array(
                        'labels' => array(
                            'name' => __('Portfolio', 'myproject'),
                            'singular_name' => __('portfolio', 'myproject')
                        ),
                        'public' => true,
                        'supports' => array('title','thumbnail','editor' ,'custom-fields','page-attributes'),
                        'menu_icon'  =>'dashicons-admin-site-alt'
                    ));



                    // Portfolio Taxonomy

                    register_taxonomy('portfolio-cat', 'portfolio',array(
                        'labels' => array(
                            'name' => __('Categories', 'myproject'),
                            'singular_name' => __('Category', 'myproject')
                        ),
                        'hierarchical' => true,
                        'show_admin_column' => true
                    )); 
                    
                
}
add_action('init', 'myproject_custom_posts');


?>